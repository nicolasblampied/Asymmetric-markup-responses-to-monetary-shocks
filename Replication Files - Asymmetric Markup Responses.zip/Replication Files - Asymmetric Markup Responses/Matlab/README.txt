This file explains the procedure to estimate the smooth local projections (SLP) in the terms Barnichon and Brownlees (2019) to the MP Shock of Jarocinski and Karadi (2020).
The main Matlab file to proceed with the estimations is Main_US_SLP.
Acknowledgements: The codes were retrieved from the supplementary material of Barnichon and Brownlees (2019) and adapted to the needs of the present paper. 



In order to replicate the main results of the paper, please note:


FIGURE 5: 

In Main_US_SLP: 


1) Select the dependent variables one at a time. Remember you can choose:

a) Mu_CD
b) Mu_CES_KVU
c) Mu_CES_KVU_OH
d) GDPG
e) Indprod (industrial production to replicate Figure 3B in the appendix)

2) Select the corresponding shock bearing in mind that:

3) Select controls. Remember to include the linear trend (TT) in this specification and to check the autocorrelation function of the shock to include its lags.

4) Run the code and get the IRFs and the 90% confidence interval one at a time.


For an explanation of the files locproj.m, locproj_conf.m, and locproj_cv.m, please see Barnichon and Brownlees (2019).

